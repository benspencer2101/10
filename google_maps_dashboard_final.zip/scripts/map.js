function initMap() {
  const defaultCenter = { lat: 54.97, lng: -1.61 };
  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 10,
    center: defaultCenter
  });

  window.setProjectLocation = function(lat, lng, name) {
    const pos = { lat: parseFloat(lat), lng: parseFloat(lng) };
    map.setCenter(pos);
    new google.maps.Marker({ position: pos, map, title: name });
  };
}
